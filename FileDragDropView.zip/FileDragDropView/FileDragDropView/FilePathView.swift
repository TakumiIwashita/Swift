//
//  FilePathView.swift
//  FileDragDropView
//
//  Created by takumi on 2019/09/21.
//  Copyright © 2019 iwashita. All rights reserved.
//

import Cocoa

class FilePathView: NSView {
    
    var acceptableTypes: Set<NSPasteboard.PasteboardType> {
        // ファイルパスを指定
        return [NSPasteboard.PasteboardType.fileURL]
    }
    var nonURLTypes: Set<NSPasteboard.PasteboardType>  {
        return [NSPasteboard.PasteboardType(rawValue: String(kUTTypeText))]
    }

    var label: NSTextField?

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
    }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
 
    override func awakeFromNib() {
        super.awakeFromNib()
        label = NSTextField(frame: NSRect(x: 20, y: self.frame.height - 200 - 20, width: self.frame.width - 40, height: 200))
        label?.stringValue = ""
        self.addSubview(label!)
    }

    func setup() {
        // Viewにドロップすることができるデータのタイプの設定
        self.registerForDraggedTypes(Array(acceptableTypes))
    }

    func shouldAllowDrag(_ draggingInfo: NSDraggingInfo) -> Bool {
        var canAccept = false
        let pasteBoard = draggingInfo.draggingPasteboard
        if pasteBoard.canReadObject(forClasses: [NSURL.self], options: nil) {
            canAccept = true
        } else if let types = pasteBoard.types, nonURLTypes.intersection(types).count > 0 {
            canAccept = true
        }
        return canAccept
    }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        let allow = shouldAllowDrag(sender)
        return allow ? .copy : NSDragOperation()
    }

    override func prepareForDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let allow = shouldAllowDrag(sender)
        return allow
    }

    // ドロップ処理ができるかを返す
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let pasteBoard = sender.draggingPasteboard as NSPasteboard
        // ドロップされたオブジェクトを読み取る
        // オプションを指定して読み取り範囲を絞り込む（今回はファイルパス）
        if let urls = pasteBoard.readObjects(forClasses: [NSURL.self], options: nil) as? [URL], urls.count > 0 {
            label?.stringValue = ""
            let files = pasteBoard.propertyList(forType: NSPasteboard.PasteboardType.fileURL) as! [String]
            for file in files {
                label?.stringValue += file + "\n"
            }
            return true
        }
        else if let types = pasteBoard.types, types.contains(NSPasteboard.PasteboardType.fileURL) {
            label?.stringValue = ""
            let files = pasteBoard.propertyList(forType: NSPasteboard.PasteboardType.fileURL) as! [String]
            for file in files {
                label?.stringValue += file + "\n"
            }
            return true
        }
        return false
    }
}


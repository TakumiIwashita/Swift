//
//  ViewController.swift
//  FileDragDropView
//
//  Created by takumi on 2019/09/22.
//  Copyright © 2019 iwashita. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet var filePathView :FilePathView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        filePathView = FilePathView()
                
    }
    
    @IBAction func ResettextButton(_ sender: NSButton) {
        filePathView.label?.stringValue = ""
    }

    
}
